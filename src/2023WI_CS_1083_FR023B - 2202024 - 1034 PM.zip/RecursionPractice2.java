public class RecursionPractice2{
	public static void main(String[] args){
		printWordBackwards("Hello");
		int[] array = {1, 3, 5, 7, 9, 11, 13, 15};
		System.out.println(binarySearch(7, array));

	}

	public static void printWordBackwards(String n){
		if(n.length() > 0){
			//Executed on the first recursive call first
			System.out.println(n.charAt(0));
			printWordBackwards(n.substring(1, n.length()));

			//Executed on the last recursive call first
			System.out.println(n.charAt(0));
		}
	}

	public static boolean binarySearch(int value, int[] searchArray){
		System.out.print("Searching array for " + value + ": ");
		for(int i = 0; i < searchArray.length; i++){
			System.out.print(searchArray[i] + ", ");
		}
		System.out.println();

		if(searchArray.length == 1){
			return value == searchArray[0];
		}
		else{
			int center = searchArray.length / 2;
			if(searchArray[center] == value){
				return true;
			}
			int[] newSearchArray = null;
			if(searchArray.length % 2 == 1){
				newSearchArray = new int[center];
				if(searchArray[center] > value){
					for(int i = 0; i < center; i++){
						newSearchArray[i] = searchArray[i];
					}
				}
				else if(searchArray[center] < value){
					int count = 0;
					for(int i = center + 1; i < searchArray.length; i++){
						newSearchArray[count++] = searchArray[i];
					}
				}
					
			}
			else{
				
				if(searchArray[center] > value){
					newSearchArray = new int[center];
					for(int i = 0; i < center; i++){
						newSearchArray[i] = searchArray[i];
					}
				}
				else if(searchArray[center] < value){
					newSearchArray = new int[center -1];
					int count = 0;
					for(int i = center + 1; i < searchArray.length; i++){
						newSearchArray[count++] = searchArray[i];
					}
				}
			}
			return binarySearch(value, newSearchArray);

		}
	}


}





