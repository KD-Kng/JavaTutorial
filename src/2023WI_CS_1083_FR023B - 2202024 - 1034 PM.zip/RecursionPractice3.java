public class RecursionPractice3{
	public static void main(String[] args){
		int[][] maze = {{1, 1, 1, 1}, {0, 1, 0, 1}, {1, 1, 0, 1}, {1, 0, 0, 1}, {1, 1, 0, 1}};
		char[][] floor1 = {{'1', '0', '0', '0'}, {'0', '1', '0', '0'}, {'1', '1', 'G', '0'}, {'0', '1', '0', '0'}};
		char[][] floor2 = {{'1', '0', '0', 'G'}, {'0', '1', '0', '0'}, {'0', '1', '1', '0'}, {'R', '0', '0', '1'}};

		//System.out.println(removeSpaces("abc x y z"));
		//System.out.println(findPath(maze, 0, 0));
		//printArray(maze);

		findSpace(floor2);
		printArray(floor2);

	}

	public static void findSpace(char[][] floor){
		boolean finished = false;
		for(int i = 0; i < floor.length; i++){
			for(int j = 0; j < floor[i].length; j++){
				if(floor[i][j] != '0' && floor[i][j] != '1'){
					paintFloor(floor, i, j, floor[i][j]);
					System.out.println();
					printArray(floor);
				}
			}

		}
	}

	private static void paintFloor(char[][] floor, int row, int col, char paint){
		//System.out.println();
		//printArray(floor);
		//Down
		if(row + 1 < floor.length && floor[row+1][col] == '0'){
			floor[row + 1][col] = paint;
			paintFloor(floor, row + 1, col, paint);
		}
		//Up
		if(row - 1 >= 0 && floor[row-1][col] == '0'){
			floor[row - 1][col] = paint;
			paintFloor(floor, row - 1, col, paint);
		}
		//Left
		if(col - 1 >= 0 && floor[row][col-1] == '0'){
			floor[row][col-1] = paint;
			paintFloor(floor, row, col - 1, paint);
		}
		//Right
		if(col + 1 < floor[row].length && floor[row][col+1] == '0'){
			floor[row][col+1] = paint;
			paintFloor(floor, row, col + 1, paint);
		}
	}

	public static boolean findPath(int[][] maze, int row, int col){
		System.out.println("\nAt position: " + row + ", " + col);
		printArray(maze);
		if(row == maze.length-1 && col == maze[row].length-1){
			maze[row][col] = 9;
			return true;
		}
		else{
			maze[row][col] = 3;
			boolean path = false;
			//Down
			if(row +1 < maze.length && maze[row+1][col] == 1){
				path = path || findPath(maze, row + 1, col);
			}
			//Right
			if(col +1 < maze[row].length && maze[row][col+1] == 1){
				path = path || findPath(maze, row, col+1);
			}

			//Up
			if(row - 1 >= 0 && maze[row-1][col] == 1){
				path = path || findPath(maze, row-1, col);
			}

			//Left
			if(col - 1 >= 0 && maze[row][col-1] == 1){
				path = path || findPath(maze, row, col-1);
			}

			if(path){
				maze[row][col] = 9;
			}
			return path;
		}
	}


/*


	public static int count7(int n){
		if(n == 0){
			return 0;
		}
		else{
			int digit = n % 10;
			n = n / 10;
			if(digit == 7){
				return 1 + count7(n); 
			}
			else{
				return count7(n);
			}
		}

	}


	public static String removeSpaces(String word){
		if(word.equals("")){
			return "";
		}
		else{
			char letter = word.charAt(0);
			if(letter == ' '){
				return removeSpaces(word.substring(1, word.length()));
			}
			else{
				return letter + removeSpaces(word.substring(1, word.length()));
			}
		}

	}

	public static boolean isPalindromeIterative(String word){
		boolean palindrome = true;
		while(word.length() >  && palindrome){
			if(word.charAt(0) != word.charAt(word.length() - 1)){
				palindrome = false;
			}
			if(word.length() > 1){
				word = word.substring(1, word.length() - 1);
			}
			else{
				word = "";
			}
			
		}
		return palindrome;
	}

	public static boolean isPalindromeRecursive(String word){
		if(word.length() <= 1){
			return true;
		}
		else if(word.charAt(0) != word.charAt(word.length() - 1)){
			return false; 
		}
		else{
			return isPalindromeRecursive(word.substring(1, word.length() - 1));
		}
	}
*/


	public static void printArray(int[][] array){
		for(int i = 0; i < array.length; i++){
			for(int j = 0; j < array[i].length; j++){
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
	}

	public static void printArray(char[][] array){
		for(int i = 0; i < array.length; i++){
			for(int j = 0; j < array[i].length; j++){
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
	}

/*
	public static boolean findPath(int[][] maze, int x, int y){
		if(x == maze.length-1 && y == maze[x].length-1){
			maze[x][y] = 9;
			return true;
		}
		else{
			maze[x][y] = 3;
			boolean pathFound = false;
			if(x - 1 >= 0 && maze[x-1][y] == 1){
				pathFound = pathFound || findPath(maze, x-1, y);

			}
			if(x + 1 < maze.length && maze[x+1][y] == 1){
				pathFound = pathFound || findPath(maze, x+1, y);
			}
			if(y - 1 >= 0 && maze[x][y-1] == 1){
				pathFound = pathFound || findPath(maze, x, y-1);
			}
			if(y + 1 < maze[x].length && maze[x][y+1] == 1){
				pathFound = pathFound || findPath(maze, x, y+1);
			}
			if(pathFound){
				//System.out.println("Here");
				maze[x][y] = 9;
			}
			return pathFound;
		}

	}
*/

}