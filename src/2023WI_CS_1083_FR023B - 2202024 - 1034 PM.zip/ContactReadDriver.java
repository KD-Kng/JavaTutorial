import java.io.*;
import java.util.Scanner;


public class ContactReadDriver{
	public static void main(String[] args){

		ObjectOutputStream outStream = null;

		try{
			File readFile = new File("contacts.csv");
			Scanner docScan = new Scanner(readFile);
			int lineNumber = 0;

			FileOutputStream fo = new FileOutputStream("contacts.dat");
			outStream = new ObjectOutputStream(fo);

			while(docScan.hasNext()){
				String line = docScan.nextLine();

				if(lineNumber != 0 && !line.equals("")){
					Scanner lineScan = new Scanner(line);
					lineScan.useDelimiter(",");

					try{
						String name = lineScan.next();						
						int month =	lineScan.nextInt();
						int year = lineScan.nextInt();

						//System.out.println(name + ":" + month + ", " + year);
						Contact contact = new Contact(name, month, year);

						outStream.writeObject(contact);
					}
					catch(Exception nsee){
						System.out.println("Error with input on line: " + lineNumber);
					}		
				}
				lineNumber++;

			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				outStream.close();
			}
			catch(Exception e){

			}			
		}

		//Read from file 
		ObjectInputStream inStream = null;
		try{
			File fin = new File("contacts.dat");
			FileInputStream fi = new FileInputStream(fin);
			inStream = new ObjectInputStream(fi);
			System.out.println("Object Read In");

			while(true){
				Contact c = (Contact)inStream.readObject();
				System.out.println(c);
			}
		}
		catch(EOFException eof){
			System.out.println("File reading successful");
		}
		catch(Exception e){

		}
		finally{
			try{
				inStream.close();
			}
			catch(Exception e){

			}			
		}

	}

}










