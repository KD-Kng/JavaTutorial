public class LinkedList{
	private Node head;

	public LinkedList(){
		head = null;
	}

	public String toString(){
		Node current = head;
		String toReturn = "";
		if(current == null){
			return "List is empty";
		}
		else{
			while(current != null){
				toReturn += current.data.toString() + "\n";
				current = current.next;
			}
			return toReturn;
		}
	}


	public void addFront(Contact toAdd){
		Node newNode = new Node(toAdd);
		newNode.next = head;
		head = newNode;
	}

	public void addEnd(Contact toAdd){
		Node addNode = new Node(toAdd);
		//Non-empty list
		if(head != null){
			Node current = head;
			while(current.next != null)
				current = current.next;
			current.next = addNode;
		}
		//Empty List
		else{
			head = addNode;
		}
	

	}

	public int size(){
		Node current = head;
		int toReturn = 0;
		while(current != null){
			toReturn++;
			current = current.next;
		}
		return toReturn;
	}

	public Contact[] toArray(){
		Contact[] toReturn = new Contact[this.size()];
		Node current = head;
		int counter = 0;
		while(current != null){
			toReturn[counter] = current.data;
			counter++;
			current = current.next;
		}
		return toReturn;
	}

	public Contact removeFront(){ //throws NoSuchElementException{
		Contact toReturn = null;
		if(head != null){
			toReturn = head.data;
			head = head.next;
		}

		return toReturn;
		
		/*else{
			throw new NoSuchElementException();
		}*/
	}

	//Approach 1: Single Pointer
	public Contact removeEnd(){
		Node current = head;
		Contact toReturn = null;
		if(current == null){
			return null;
		}
		else if(current.next == null){
			toReturn = current.data;
			head = null;
			return toReturn;
		}
		else{
			while(current.next.next != null)
				current = current.next;
			toReturn = current.next.data;
			current.next = null;
			return toReturn;
		}
	}

	//Approach 2: Two Pointers
	public Contact removeEnd(){
		Node previous = null;
		Node current = head;
		Contact toReturn = null;
		if(current == null){
			return null;
		}
		else{
			while(current.next != null){
				previous = current;
				current = current.next;
			}
			toReturn = current.data;
			previous.next = null;
			return toReturn;
		}

	}
	
	//May not be complete, but to help with the lab
	public void addOrder(Node newNode){
		Node current = head;
		Node previous = null;
		if(head == null){
			head = newNode;
		}
		else{
			while(current != null && current.data.compareTo(newNode.data) < 0){
				previous = current;
				current = current.next;
			}
			previous.next = newNode;
			newNode.next = current;
		}
	}

	private class Node{
		public Contact data;
		public Node next;

		public Node(Contact dataIn){
			data = dataIn;
			next = null;
		}
	}
}