public class ChessExample{
	public static void main(String[] args){
		System.out.println(canTakeKing(6, 2, 7, 2, 3, 5));
	}

	public static boolean canCheckKing(int rBis, int cBis, int rYourKing, int cYourKing, int rOtherKing, int cOtherKing){
		int currentRBis = rBis;
		int currentCBis = cBis;
		boolean check = false;

		//Up and to the Left
		while(currentRBis + 1 < 8 && currentCBis - 1 >==0 && !check && (currentRBis != rOtherKing && currentCBis != cOtherKing)){
			currentRBis++;
			currentCBis--;
			if(currentRBis == rOtherKing && currentCBis == cOtherKing){
				check = true;
			}
			else{
				check = check || canTakeKing(currentRBis, currentCBis, rYourKing, cYourKing, rOtherKing, cOtherKing);
			}
		}

		return check;
	}

	public static boolean canTakeKing(int rBis, int cBis, int rYourKing, int cYourKing, int rOtherKing, int cOtherKing){
		return uLCTK(rBis + 1, cBis - 1, rYourKing, cYourKing, rOtherKing, cOtherKing)
			|| uRCTK(rBis + 1, cBis + 1, rYourKing, cYourKing, rOtherKing, cOtherKing)
			|| dLCTK(rBis - 1, cBis - 1, rYourKing, cYourKing, rOtherKing, cOtherKing)
			|| dRCTK(rBis - 1, cBis + 1, rYourKing, cYourKing, rOtherKing, cOtherKing);
	}
	public static boolean uLCTK(int rBis, int cBis, int rYourKing, int cYourKing, int rOtherKing, int cOtherKing){
		if(rBis >= 8 || cBis< 0){
			return false;
		}
		else if(rBis == rOtherKing && cBis == cOtherKing){
			return true;
		}
		else if(rBis == rYourKing && cBis == cYourKing){
			return false;
		}
		else{
			return uLCTK(rBis + 1, cBis - 1, rYourKing, cYourKing, rOtherKing, cOtherKing);
		}
	}
	public static boolean uRCTK(int rBis, int cBis, int rYourKing, int cYourKing, int rOtherKing, int cOtherKing){
		if(rBis >= 8 || cBis >=8){
			return false;
		}
		else if(rBis == rOtherKing && cBis == cOtherKing){
			return true;
		}
		else if(rBis == rYourKing && cBis == cYourKing){
			return false;
		}
		else{
			return uRCTK(rBis + 1, cBis + 1, rYourKing, cYourKing, rOtherKing, cOtherKing);
		}
	}
	public static boolean dLCTK(int rBis, int cBis, int rYourKing, int cYourKing, int rOtherKing, int cOtherKing){
		if(rBis < 0 || cBis < 0){
			return false;
		}
		else if(rBis == rOtherKing && cBis == cOtherKing){
			return true;
		}
		else if(rBis == rYourKing && cBis == cYourKing){
			return false;
		}
		else{
			return dLCTK(rBis - 1, cBis - 1, rYourKing, cYourKing, rOtherKing, cOtherKing);
		}
	}
	public static boolean dRCTK(int rBis, int cBis, int rYourKing, int cYourKing, int rOtherKing, int cOtherKing){
		if(rBis < 0 || cBis >=8){
			return false;
		}
		else if(rBis == rOtherKing && cBis == cOtherKing){
			return true;
		}
		else if(rBis == rYourKing && cBis == cYourKing){
			return false;
		}
		else{
			return dRCTK(rBis - 1, cBis + 1, rYourKing, cYourKing, rOtherKing, cOtherKing);
		}
	}


}