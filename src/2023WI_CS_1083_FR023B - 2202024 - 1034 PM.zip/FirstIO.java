import java.io.*;
import java.util.Scanner;

public class FirstIO{
	public static void main(String[] args){
		Scanner fileNameReader = new Scanner(System.in);
		System.out.println("Please input a file to read from");
		String fileInName = fileNameReader.nextLine();
		System.out.println("Please input a file to write to");
		String fileOutName = fileNameReader.nextLine();

		PrintWriter pw = null;

		try{
			File fileIn = new File(fileInName);
			Scanner reader = new Scanner(fileIn);

			File fileOut = new File(fileOutName);
			pw = new PrintWriter(fileOut);

			while(reader.hasNext()){
				String lineReadIn = reader.nextLine();
				pw.println(lineReadIn);
			}

			pw.close();
		}
		catch(Exception e){
			System.out.println("Error occurred");
			e.printStackTrace();
			if(pw != null){
				pw.close();
			}
			System.exit(1);
		}



	}

}