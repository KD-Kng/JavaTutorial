public class Sorter<T extends Comparable<T>>{

	public void selectionSort(T[] list){
		for(int outer = 0; outer < list.length - 1; outer++){
			int min = outer;
			for(int inner = outer+1; inner < list.length; inner++){
				if(list[min].compareTo(list[inner]) > 0){
					min = inner;
				}
			}
			//swap
			T holder = list[min];
			list[min] = list[outer];
			list[outer] = holder;
		}
	}


	public void insertionSort(T[] list){
		for(int i = 1; i < list.length; i++){
			T temp = list[i];
			int j = i - 1;
			
			while(j >= 0 && list[j].compareTo(temp) > 0){
				list[j+1] = list[j];
				j--;
			}
			list[j+1] = temp;
		}
	}
}


