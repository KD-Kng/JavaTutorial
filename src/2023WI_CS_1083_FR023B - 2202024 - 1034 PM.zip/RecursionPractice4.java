public class RecursionPractice4{
	public static void main(String[] args){
		int[] array = {2, 4, 5, 7, 9, 10, 11, 12};
		subsetSums(array, 0, 0);
	}

	public static int multiply(int a, int b){
		if(a <= 0 || b <= 0){
			return 0;
		}
		else{
			return b + multiply(a-1, b);
		}
	}

	public static void subsetSums(int[] arr, int l, int sum){
		if(l == arr.length){
			System.out.print(sum + " ");
		}
		else{
			//Including the value
			subsetSums(arr, l + 1, sum + arr[l]);

			//Excluding the value
			subsetSums(arr, l + 1, sum);
		}

	}

	public static int numB(String word){
		if(word.length() == 0){
			return 0;
		}
		else{
			if(word.charAt(0) == 'b' || word.charAt(0) == 'B'){
				return 1 + numB(word.substring(1));
			}
		}

	}



}