import java.io.*;
import java.util.Scanner;

public class CSVExample{
	public static void main(String[] args){
		Scanner fileNameReader = new Scanner(System.in);
		System.out.println("Please input a file to read from");
		String fileInName = fileNameReader.nextLine();

		try{
			File fileIn = new File(fileInName);
			Scanner reader = new Scanner(fileIn);

			double sum1 = 0;
			double sum2 = 0;
			int numTests = 0;

			while(reader.hasNext()){
				numTests++;
				String lineReadIn = reader.nextLine();
				Scanner lineReader = new Scanner(lineReadIn);
				lineReader.useDelimiter(",");
				String studentName = lineReader.next();

				String testVal = lineReader.next();
				if(!testVal.equals("")){
					sum1 += Double.parseDouble(testVal);
				}

				if(lineReader.hasNext()){
					testVal = lineReader.next();
					if(!testVal.equals("")){
						sum2 += Double.parseDouble(testVal);
					}
				}
				
			}

			System.out.println("Test 1 average: " + (sum1/numTests));
			System.out.println("Test 2 average: " + (sum2/numTests));
		}
		catch(Exception e){
			System.out.println("Error occurred");
			e.printStackTrace();
			System.exit(1);
		}



	}

}