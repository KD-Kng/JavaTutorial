public class Stack<T>{
	private T[] array;
	private int count;

	//Stack<Contact> stack = new Stack<Contact>();
	//Maximum values do not need to be provided, but for this example
	//we will have one
	public Stack(int max){
		count = 0;
		array = new T[max];
	}

	public boolean push(T obj){
		if(count == array.length){
			return false;
		}
		else{
			array[count] = obj;
			count++;
			return true;
		}
	}

	public T pop(){
		if(count == 0){
			return null;
		}
		else{
			count--;
			return array[count];
		}
	}

	public boolean isEmpty(){
		return count == 0;
	}

	public int size(){
		return count;
	}

	public T peek(){
		if(count == 0){
			return null;
		}
		else{
			return array[count-1];
		}
	}
}