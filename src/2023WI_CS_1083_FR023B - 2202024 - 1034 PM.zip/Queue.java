public class Queue<T>{
	private T[] array;
	private int count;

	//Maximum values do not need to be provided, but for this example
	//we will have one
	public Queue(int max){
		array = new T[max];
		count = 0;
	}

	//Add to the end
	public boolean enqueue(T obj){
		if(count == array.length){
			return false;
		}
		else{
			array[count] = obj;
			count++;
			return true;
		}
	}

	//Remove from the front
	public T dequeue(){
		if(count == 0){
			return null;
		}
		else{
			T toReturn = array[0];
			count--;
			for(int i = 0; i < count; i++){
				array[i] = array[i+1];
			}
			return toReturn;
		}
	}

	public boolean isEmpty(){
		return count == 0;
	}

	public int size(){
		return count;
	}

	public T peek(){
		if(count == 0){
			return null;
		}
		else{
			return  array[0];
		}
	}
}