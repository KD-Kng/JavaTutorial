/*
*	An additional example to Review to understand finally
*	Important to review for midterm
*/

public class ExceptionPractice2{
	public static void main(String[] args){
		try{
			methodA("10.5");
		}
		catch(Exception e){
			System.out.println("Exception Caught in Main");
		}
		finally{
			System.out.println("Finally - main");
		}

		
	}

	public static void methodA(String value) throws NoSuchMethodException{
		try{
			methodB(value);
		}
		catch(Exception e){
			System.out.println("Exception Caught in methodA");
		}
		finally{
			System.out.println("Finally - methodA");
		}

		
	}

	public static void methodB(String value){
		try{
			int newVal = Integer.parseInt(value);
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Exception Caught in methodA");
		}
		finally{
			System.out.println("Finally - methodB");
		}
		
	}
} 