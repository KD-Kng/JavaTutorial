import java.io.Serializable;

public class Contact implements Serializable, Comparable<Contact>{

	private int month;
	private int year;
	private String name;
	
	public Contact(String name, int month, int year){
		this.name = name;
		this.month = month; 
		this.year = year;
	}
	
	public String getName(){
		return name;
	}	
	
	//Compare based on name only. Assume names will be unique
	public int compareTo(Contact other){
		int toReturn = this.name.compareTo(other.getName());
		return toReturn;
	}
	
	public String toString(){
		return name + ": " + month + "-" + year;
	}
}

